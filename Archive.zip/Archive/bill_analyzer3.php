<!DOCTYPE html>
<html>
<head>
<title>Bill Analyzer</title>
</head>
<body>

<h1>Bill Analyzer</h1>

<form method="get" action="analyzer.php">
  <label for="bill_id">Bill ID:</label>
  <input type="number" id="bill_id" name="bill_id" required><br><br>
  <input type="submit" value="Analyze">
</form>

</body>
</html>